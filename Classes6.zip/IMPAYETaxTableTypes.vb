Public Class IMPAYETaxTableTypes



End Class
