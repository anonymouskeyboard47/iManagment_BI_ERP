Public Class IMSendEmail
    
End Class
