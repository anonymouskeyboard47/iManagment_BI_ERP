Public Class IMBuildingQuantityRoomItem
    '    RoomID
    'QuantityItem
    'QuantityItemCost
End Class
