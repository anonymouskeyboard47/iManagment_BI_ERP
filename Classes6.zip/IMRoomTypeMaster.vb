Public Class IMBuildingRoomTypes
    '    RoomTypeID
    'RoomType
    'RoomTypeDescription
End Class
