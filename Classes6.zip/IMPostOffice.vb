Option Explicit On 
Option Strict On

Imports System
Imports System.Data
Imports System.Data.OleDb
Imports System.Collections

Public Class IMPostOffice

#Region "PrivateVariables"

#End Region

#Region "InitializationProcedures"
    Public Sub New()
        MyBase.New()
    End Sub
#End Region


End Class
