Public Class IMCheckDongle



End Class
