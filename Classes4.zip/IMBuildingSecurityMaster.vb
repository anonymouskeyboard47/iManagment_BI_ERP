Public Class IMBuildingSecurityMaster
    '    SecurityID
    'SecurityDescription
End Class
