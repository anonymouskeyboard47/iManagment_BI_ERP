Public Class IMBuildingFloorMaster
    '    BuildingID
    'FloorID
    'FloorDescription
End Class
