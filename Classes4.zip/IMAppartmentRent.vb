Public Class IMAppartmentRent
    '    BuildingID
    'FloorID
    'SecurityID
End Class
