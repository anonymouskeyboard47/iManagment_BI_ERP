Public Class IMXMLEncryptionAndSignature

    'CryptCreateHash
    Public Function CreateTheHash(ByVal bEnableCryptUIWiz As Boolean)

    End Function

    'CryptDestroyHash
    Public Function DestroyTheDigitalSignature()

    End Function

    'CryptVerifyDigitalSignature
    Public Function VerfirDigitalSignature()

    End Function

    'CryptSighHash
    Public Function SignDocWithHash()

    End Function
End Class
