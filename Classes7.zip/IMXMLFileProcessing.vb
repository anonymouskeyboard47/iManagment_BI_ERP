Public Class IMXMLFileProcessing

    Public Function ProduceXMLOrder(ByVal dtTable As Object) _
        As Xml.XmlDocument

    End Function



End Class
