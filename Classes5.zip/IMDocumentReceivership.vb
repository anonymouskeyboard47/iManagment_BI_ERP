Public Class IMDocumentReceivership

    '    DocumentID
    'ReceivershipID
    'DocumentReceiverUserID
    'ReceivedDate

End Class
