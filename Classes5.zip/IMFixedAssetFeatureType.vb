Public Class IMFixedAssetFeatureType
    
End Class
