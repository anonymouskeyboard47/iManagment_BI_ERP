Public Class IMFixedAssetAccessories
    
End Class
