Public Class IMFixedAssetAccessoriesTypes



End Class
