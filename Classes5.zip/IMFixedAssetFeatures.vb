Public Class IMFixedAssetFeatures
    
End Class
